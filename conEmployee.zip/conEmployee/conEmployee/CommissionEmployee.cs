﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace conEmployee
{
    internal class CommissionEmployee:Employee
    {
        private double sales;
        private double percentage;

        public double Sales { get; set; }
        public double Percentage { get; set; }

        public CommissionEmployee(string empID, string name, int age, double sales, double percentage)
        {
            base.EmpID = empID;
            base.Name = name;
            base.Age = age;
            this.Sales = sales;
            this.Percentage = percentage;
        }

        public override string ToString()
        {
            return "\nEmployee ID: " + base.EmpID +
                "\nName: " + base.Name +
                "\nAge: " + base.Age +
                "\nSales: " + this.Sales +
                "\nPercentage: " + this.Percentage +
                "\nCommission Employee: " + this.ComputePay();
        }

        public override double ComputePay()
        {
            return Sales * Percentage;
        }
    }
}
