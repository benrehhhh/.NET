﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace conEmployee
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int option = 0;
            do
            {
                Console.WriteLine("\n=----------= SELECT AN OPTION =---------=");
                Console.WriteLine("1. Employee");
                Console.WriteLine("2. Hourly Employee");
                Console.WriteLine("3. Commission Employee");
                Console.WriteLine("4. Exit");
                Console.WriteLine("=---------------------------------------=");
                Console.Write("Select an Option: ");
                Employee emp;

                if (int.TryParse(Console.ReadLine(), out option))
                {
                    switch (option)
                    {
                        case 1:
                            Console.WriteLine();
                            Console.WriteLine("=----------------Employee---------------=");
                            Console.Write("Enter Employee ID: ");
                            string empID = Console.ReadLine();
                            Console.Write("Name: ");
                            string name = Console.ReadLine();
                            Console.Write("Age: ");
                            int age = int.Parse(Console.ReadLine());
                            emp = new Employee(empID, name, age);
                            Console.WriteLine(emp);
                            break;

                        case 2:
                            Console.WriteLine();
                            Console.WriteLine("=-------------Hours Worked--------------=");
                            Console.Write("Hours Worked: ");
                            double hoursWorked = int.Parse(Console.ReadLine());
                            Console.Write("Hourly Rate: ");
                            double hourlyRate = int.Parse(Console.ReadLine());
                            emp = new HourlyEmployee("12345", "Ardiente", 21, hoursWorked, hourlyRate);
                            Console.WriteLine(emp);
                            break;

                        case 3:
                            Console.WriteLine();
                            Console.WriteLine("=--------Commission Employee------------=");
                            Console.Write("Sales: ");
                            double sales = int.Parse(Console.ReadLine());
                            Console.Write("Percentage: ");
                            double percentage = int.Parse(Console.ReadLine());
                            emp = new CommissionEmployee("12345", "Ardiente", 21, sales, percentage);
                            Console.WriteLine(emp);
                            break;
                        
                        case 4:
                            Console.WriteLine("Exit Complete.");
                            break;

                        default:
                            Console.WriteLine("Invalid Option. Please Try Again.");
                            break;
                    }
                }
                else
                {
                    Console.WriteLine("Invalid input. Please enter a number.");
                }
            } while (option != 4);
        }
    }
}
