﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace conEmployee
{
    internal class Employee
    {
        private string empId;
        private string name;
        private int age;

        public Employee() { }

        public Employee(string empID, string name, int age)
        {
            this.EmpID = empID;
            this.Name = name;
            this.Age = age;
        }

        public string EmpID { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }

        public override string ToString()
        {
            return "\nEmployee ID: " + this.EmpID +
                "\n Name: " + this.Name +
                "\nAge: " + this.Age +
                "\nEmployee Pay: " + this.ComputePay();
        }

        public virtual double ComputePay()
        {
            return 0.0;
        }

    }
}
