﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace conEmployee
{
    internal class HourlyEmployee:Employee
    {
        private double hoursWorked;
        private double hourlyRate;

        public double HoursWorked { get; set; }
        public double HourlyRate { get; set; }

        public HourlyEmployee(string empID, string name, int age, double hoursWorked, double hourlyRate)
        {
            base.EmpID = empID;
            base.Name = name;
            base.Age = age;
            this.HoursWorked = hoursWorked;
            this.HourlyRate = hourlyRate;
        }

        public override string ToString()
        {
            return "\nEmployee ID: " + base.EmpID +
                "\nName: " + base.Name +
                "\nAge: " + base.Age +
                "\nHours Worked: " + this.HoursWorked +
                "\nHourly Rate: " + this.HourlyRate +
                "\nPer Hour Rate: " + this.ComputePay();
        }

        public override double ComputePay()
        {
            return HoursWorked * HourlyRate;
        }
    }
}
