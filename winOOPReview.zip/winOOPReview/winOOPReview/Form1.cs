﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace winOOPReview
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {
        }

        private void Square_CheckedCHanged(object sender, EventArgs e)
        {
            grpSquare.Visible = false;
            picSquare.Visible = false;
            picCircle.Visible = false;
            grpCircle.Visible = false;
            picCircle.Visible = false;
            grpRectangle.Visible = true;
            picRectangle.Visible = true;
        }
        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            grpSquare.Visible = false;
            picSquare.Visible = false;
            picCircle.Visible = false;
            grpCircle.Visible = false;
            picCircle.Visible = false;
            grpRectangle.Visible = true;
            picRectangle.Visible = true;
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            grpSquare.Visible = false;
            picSquare.Visible = false;
            picCircle.Visible = false;
            grpCircle.Visible = true;
            picCircle.Visible = true;
            grpRectangle.Visible = false;
            picRectangle.Visible = false;
        }


        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void groupBox4_Enter(object sender, EventArgs e)
        {

        }

        private void grpRectangle_Enter(object sender, EventArgs e)
        {

        }

        private void Square_CheckedChanged_1(object sender, EventArgs e)
        {
            grpSquare.Visible = true;
            picSquare.Visible = true;
            picCircle.Visible = false;
            grpCircle.Visible = false;
            picCircle.Visible = false;
            grpRectangle.Visible = false;
            picRectangle.Visible = false;
        }

        private void sbmtCompute_Click(object sender, EventArgs e)
        {
            double area = 0;

            if (rbtnSquare.Checked)
            {
                double side = Convert.ToDouble(txtSideLength.Text);
                area = side * side;
            }
            else if (rbtnRectangle.Checked)
            {
                double length = Convert.ToDouble(txtLength.Text);
                double width = Convert.ToDouble(txtWidth.Text);
                area = length * width;
            }
            else if (rbtnCircle.Checked)
            {
                double radius = Convert.ToDouble(txtRadius.Text);
                area = Math.PI * radius * radius;
            }
            else
            {
                MessageBox.Show("Please select a shape.");
                return;
            }

            lblResult.Text = area.ToString("F2");
        }
    }
}
