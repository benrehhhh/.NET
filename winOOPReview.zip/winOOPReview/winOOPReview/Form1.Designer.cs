﻿namespace winOOPReview
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rbtnSquare = new System.Windows.Forms.RadioButton();
            this.rbtnCircle = new System.Windows.Forms.RadioButton();
            this.rbtnRectangle = new System.Windows.Forms.RadioButton();
            this.grpSquare = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtSideLength = new System.Windows.Forms.TextBox();
            this.grpCircle = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtRadius = new System.Windows.Forms.TextBox();
            this.grpRectangle = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtWidth = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtLength = new System.Windows.Forms.TextBox();
            this.sbmtCompute = new System.Windows.Forms.Button();
            this.picSquare = new System.Windows.Forms.PictureBox();
            this.picRectangle = new System.Windows.Forms.PictureBox();
            this.picCircle = new System.Windows.Forms.PictureBox();
            this.lblResult = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.grpSquare.SuspendLayout();
            this.grpCircle.SuspendLayout();
            this.grpRectangle.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picSquare)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRectangle)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCircle)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rbtnSquare);
            this.groupBox1.Controls.Add(this.rbtnCircle);
            this.groupBox1.Controls.Add(this.rbtnRectangle);
            this.groupBox1.Location = new System.Drawing.Point(39, 35);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(183, 135);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Shape";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // rbtnSquare
            // 
            this.rbtnSquare.AutoSize = true;
            this.rbtnSquare.Location = new System.Drawing.Point(19, 33);
            this.rbtnSquare.Name = "rbtnSquare";
            this.rbtnSquare.Size = new System.Drawing.Size(59, 17);
            this.rbtnSquare.TabIndex = 9;
            this.rbtnSquare.TabStop = true;
            this.rbtnSquare.Text = "Square";
            this.rbtnSquare.UseVisualStyleBackColor = true;
            this.rbtnSquare.CheckedChanged += new System.EventHandler(this.Square_CheckedChanged_1);
            // 
            // rbtnCircle
            // 
            this.rbtnCircle.AutoSize = true;
            this.rbtnCircle.Location = new System.Drawing.Point(19, 100);
            this.rbtnCircle.Name = "rbtnCircle";
            this.rbtnCircle.Size = new System.Drawing.Size(51, 17);
            this.rbtnCircle.TabIndex = 6;
            this.rbtnCircle.TabStop = true;
            this.rbtnCircle.Text = "Circle";
            this.rbtnCircle.UseVisualStyleBackColor = true;
            this.rbtnCircle.CheckedChanged += new System.EventHandler(this.radioButton3_CheckedChanged);
            // 
            // rbtnRectangle
            // 
            this.rbtnRectangle.AutoSize = true;
            this.rbtnRectangle.Location = new System.Drawing.Point(19, 65);
            this.rbtnRectangle.Name = "rbtnRectangle";
            this.rbtnRectangle.Size = new System.Drawing.Size(74, 17);
            this.rbtnRectangle.TabIndex = 6;
            this.rbtnRectangle.TabStop = true;
            this.rbtnRectangle.Text = "Rectangle";
            this.rbtnRectangle.UseVisualStyleBackColor = true;
            this.rbtnRectangle.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // grpSquare
            // 
            this.grpSquare.Controls.Add(this.label1);
            this.grpSquare.Controls.Add(this.txtSideLength);
            this.grpSquare.Location = new System.Drawing.Point(58, 186);
            this.grpSquare.Name = "grpSquare";
            this.grpSquare.Size = new System.Drawing.Size(200, 100);
            this.grpSquare.TabIndex = 6;
            this.grpSquare.TabStop = false;
            this.grpSquare.Text = "Properties";
            this.grpSquare.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "Side Length";
            // 
            // txtSideLength
            // 
            this.txtSideLength.Location = new System.Drawing.Point(83, 45);
            this.txtSideLength.Name = "txtSideLength";
            this.txtSideLength.Size = new System.Drawing.Size(100, 20);
            this.txtSideLength.TabIndex = 0;
            // 
            // grpCircle
            // 
            this.grpCircle.Controls.Add(this.label4);
            this.grpCircle.Controls.Add(this.txtRadius);
            this.grpCircle.Location = new System.Drawing.Point(58, 185);
            this.grpCircle.Name = "grpCircle";
            this.grpCircle.Size = new System.Drawing.Size(200, 100);
            this.grpCircle.TabIndex = 8;
            this.grpCircle.TabStop = false;
            this.grpCircle.Text = "Properties";
            this.grpCircle.Enter += new System.EventHandler(this.groupBox4_Enter);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(23, 38);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(40, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "Radius";
            // 
            // txtRadius
            // 
            this.txtRadius.Location = new System.Drawing.Point(83, 35);
            this.txtRadius.Name = "txtRadius";
            this.txtRadius.Size = new System.Drawing.Size(100, 20);
            this.txtRadius.TabIndex = 0;
            // 
            // grpRectangle
            // 
            this.grpRectangle.Controls.Add(this.label3);
            this.grpRectangle.Controls.Add(this.txtWidth);
            this.grpRectangle.Controls.Add(this.label2);
            this.grpRectangle.Controls.Add(this.txtLength);
            this.grpRectangle.Location = new System.Drawing.Point(58, 185);
            this.grpRectangle.Name = "grpRectangle";
            this.grpRectangle.Size = new System.Drawing.Size(200, 100);
            this.grpRectangle.TabIndex = 7;
            this.grpRectangle.TabStop = false;
            this.grpRectangle.Text = "Properties";
            this.grpRectangle.Enter += new System.EventHandler(this.grpRectangle_Enter);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(23, 63);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "Width";
            // 
            // txtWidth
            // 
            this.txtWidth.Location = new System.Drawing.Point(64, 56);
            this.txtWidth.Name = "txtWidth";
            this.txtWidth.Size = new System.Drawing.Size(100, 20);
            this.txtWidth.TabIndex = 9;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(23, 33);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Length";
            // 
            // txtLength
            // 
            this.txtLength.Location = new System.Drawing.Point(64, 30);
            this.txtLength.Name = "txtLength";
            this.txtLength.Size = new System.Drawing.Size(100, 20);
            this.txtLength.TabIndex = 9;
            // 
            // sbmtCompute
            // 
            this.sbmtCompute.Location = new System.Drawing.Point(63, 292);
            this.sbmtCompute.Name = "sbmtCompute";
            this.sbmtCompute.Size = new System.Drawing.Size(84, 30);
            this.sbmtCompute.TabIndex = 2;
            this.sbmtCompute.Text = "Compute";
            this.sbmtCompute.UseVisualStyleBackColor = true;
            this.sbmtCompute.Click += new System.EventHandler(this.sbmtCompute_Click);
            // 
            // picSquare
            // 
            this.picSquare.Image = global::winOOPReview.Properties.Resources.square;
            this.picSquare.Location = new System.Drawing.Point(281, 35);
            this.picSquare.Name = "picSquare";
            this.picSquare.Size = new System.Drawing.Size(146, 135);
            this.picSquare.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picSquare.TabIndex = 4;
            this.picSquare.TabStop = false;
            // 
            // picRectangle
            // 
            this.picRectangle.Image = global::winOOPReview.Properties.Resources.rectangle;
            this.picRectangle.Location = new System.Drawing.Point(281, 35);
            this.picRectangle.Name = "picRectangle";
            this.picRectangle.Size = new System.Drawing.Size(146, 135);
            this.picRectangle.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picRectangle.TabIndex = 3;
            this.picRectangle.TabStop = false;
            // 
            // picCircle
            // 
            this.picCircle.Image = global::winOOPReview.Properties.Resources.circle;
            this.picCircle.Location = new System.Drawing.Point(281, 35);
            this.picCircle.Name = "picCircle";
            this.picCircle.Size = new System.Drawing.Size(144, 135);
            this.picCircle.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picCircle.TabIndex = 2;
            this.picCircle.TabStop = false;
            // 
            // lblResult
            // 
            this.lblResult.AutoSize = true;
            this.lblResult.Location = new System.Drawing.Point(182, 301);
            this.lblResult.Name = "lblResult";
            this.lblResult.Size = new System.Drawing.Size(40, 13);
            this.lblResult.TabIndex = 9;
            this.lblResult.Text = "Result:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(455, 450);
            this.Controls.Add(this.lblResult);
            this.Controls.Add(this.sbmtCompute);
            this.Controls.Add(this.grpRectangle);
            this.Controls.Add(this.grpCircle);
            this.Controls.Add(this.grpSquare);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.picSquare);
            this.Controls.Add(this.picRectangle);
            this.Controls.Add(this.picCircle);
            this.Name = "Form1";
            this.Text = "OOP Review";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.grpSquare.ResumeLayout(false);
            this.grpSquare.PerformLayout();
            this.grpCircle.ResumeLayout(false);
            this.grpCircle.PerformLayout();
            this.grpRectangle.ResumeLayout(false);
            this.grpRectangle.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picSquare)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRectangle)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCircle)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.PictureBox picCircle;
        private System.Windows.Forms.PictureBox picRectangle;
        private System.Windows.Forms.PictureBox picSquare;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rbtnSquare;
        private System.Windows.Forms.RadioButton rbtnCircle;
        private System.Windows.Forms.RadioButton rbtnRectangle;
        private System.Windows.Forms.GroupBox grpSquare;
        private System.Windows.Forms.GroupBox grpRectangle;
        private System.Windows.Forms.TextBox txtSideLength;
        private System.Windows.Forms.TextBox txtWidth;
        private System.Windows.Forms.TextBox txtLength;
        private System.Windows.Forms.GroupBox grpCircle;
        private System.Windows.Forms.TextBox txtRadius;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button sbmtCompute;
        private System.Windows.Forms.Label lblResult;
    }
}

