﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace conShape
{
    internal class Rectangle:Shape
    {
        private double width;
        private double length;

        public double Length { get => length; set => length = value; }
        public double Width { get => width; set => width = value; }

        public Rectangle(string name, string color, int noSide, double width, double length)
        {
            base.Name = name;
            base.Color = color;
            base.NoSide = noSide;
            this.Width = width;
            this.Length = length;
        }
        public override double ComputeArea()
        {
            return this.length * this.width;
        }

        public override string ToString()
        {
            return "\nName: " + base.Name +
                "\nColor: " + base.Color +
                "\nNo. of Side: " + base.NoSide +
                "\nWidth: " + this.Width +
                "\nHeight: " + this.Length +
                "\nArea of a Rectangle: " + this.ComputeArea();
        }
    }
}
