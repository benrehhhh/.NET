﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace conShape
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int option = 0;
            do
            {
                Console.WriteLine("=\n----------= SELECT AN OPTION =---------=");
                Console.WriteLine("1. Shape");
                Console.WriteLine("2. Square");
                Console.WriteLine("3. Rectangle");
                Console.WriteLine("4. Circle");
                Console.WriteLine("5. Exit");
                Console.WriteLine("=---------------------------------------=");
                Console.Write("Select an Option: ");
                Shape sh;

                if (int.TryParse(Console.ReadLine(), out option))
                {
                    switch (option)
                    {
                        case 1:
                            Console.WriteLine();
                            Console.WriteLine("======= SHAPE =======");
                            Console.Write("Enter Name: ");
                            string name = Console.ReadLine();
                            Console.Write("Enter Color: ");
                            string color = Console.ReadLine();
                            Console.Write("No. of Side: ");
                            int noSide = int.Parse(Console.ReadLine());
                            sh = new Shape("Shape", color, noSide);
                            Console.WriteLine(sh);
                            break;
                        case 2:
                            Console.WriteLine();
                            Console.WriteLine("====== SQUARE =======");
                            Console.Write("Enter Side Length: ");
                            double sideLength = double.Parse(Console.ReadLine());
                            sh = new Square("Square", "Red", 4, sideLength);
                            Console.WriteLine(sh);
                            break;
                        case 3:
                            Console.WriteLine();
                            Console.WriteLine("===== RECTANGLE ======");
                            Console.Write("Enter Width: ");
                            double width = double.Parse(Console.ReadLine());
                            Console.Write("Enter Height: ");
                            double height = double.Parse(Console.ReadLine());
                            sh = new Rectangle("Rectangle", "Red", 4, width, height);
                            Console.WriteLine(sh);
                            break;
                        case 4:
                            Console.WriteLine();
                            Console.WriteLine("======= CIRCLE =======");
                            Console.Write("Enter Radius: ");
                            double radius = double.Parse(Console.ReadLine());
                            sh = new Circle("Circle", "Red", 0, radius);
                            Console.WriteLine(sh);
                            break;

                        case 5:
                            Console.WriteLine("Exit Complete.");
                            break;

                        default:
                            Console.WriteLine("Invalid Option please try again.");
                            break;
                    }
                }
                else
                {
                    Console.WriteLine("Invalid input. Please enter a number.");
                }
            } while (option != 5);
        }
    }
}
