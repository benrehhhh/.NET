﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace conShape
{
    internal class Square:Shape
    {
        private double sideLength;

        public double SideLength { get; set; }

        public Square(string name, string color, int noSide, double sideLength)
        {
            base.Name = name;
            base.Color = color;
            base.NoSide = noSide;
            this.sideLength = sideLength;
        }

        public override string ToString()
        {
            return "\nName: " + base.Name +
                "\nColor: " + base.Color +
                "\nNo. of Side: " + base.NoSide +
                "\nLength of one side: " + this.SideLength +
                "\nArea of a Square: " + this.ComputeArea();
        }

        public override double ComputeArea()
        {
            return Math.Pow(this.sideLength,2);
        }
    }   
}
