﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace conShape
{
    internal class Shape
    {
        public Shape() { }

        public Shape(string name, string color, int noSide)
        {
            this.Name = name;
            this.Color = color;
            this.NoSide = noSide;
        }

        public string Name { get; set; }
        public string Color { get; set; }
        public int NoSide { get; set; }

        public override string ToString()
        {
            return "\nName: " + this.Name +
                "\n Color: " + this.Color +
                "\n No. of Side: " + this.NoSide +
                "\n Area of a Shape: " + this.ComputeArea();
        }

        public virtual double ComputeArea()
        {
            return 0.0;
        }
    }
}