﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace conShape
{
    internal class Circle:Shape
    {
        private double radius;

        public double Radius { get => radius; set => radius = value; }

        public Circle(string name, string color, int noSide, double radius)
        {
            base.Name = name;
            base.Color = color;
            base.NoSide = noSide;
            this.Radius = radius;
        }

        public override double ComputeArea()
        {
            return Math.PI * Math.Pow(this.radius, 2);
        }

        public override string ToString()
        {
            return "\nName: " + base.Name +
                "\nColor: " + base.Color +
                "\nNo. of Side: " + base.NoSide +
                "\nRadius: " + this.Radius +
                "\nArea of a Circle: " + this.ComputeArea();
        }

    }
}
